#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define BUFLEN 256

void error(char *msg)
{
    perror(msg);
    exit(1);
}


/*
    Sparge uns tring in cuvinte separate prin spatiu.
    (MAX 10 cuv)
*/
char ** split(char * s) {
    char ** strings = (char **)calloc(10, sizeof(char *));
    int len = strlen(s);
    int lastIndex = 0;
    int i;
    int k = 0;

    for (i = 0; i <= len; i++) {
        if (s[i] == ' ' || s[i] == '\0' || s[i] == '\n') {

            strings[k] = (char *)calloc(20, sizeof(char));
            memcpy(strings[k], s + lastIndex, i - lastIndex);
            lastIndex = i + 1;
            k++;
        }
    }
    return strings;
}

int main(int args, char ** argv) {
	struct sockaddr_in structUDP, serverStructUDP;
	struct sockaddr_in structTCP;
    char * buf = (char *)calloc(BUFLEN, sizeof(char));

    int enable = 1;
	int socketTCP; //socket-ul structului TCP
	int socketUDP; //socket-ul structului UDP
    int processID = getpid();
    int loginFlag = 0;
    int quitFlag = 0;
    int serverStructUDPlen = sizeof(serverStructUDP); //pentru recvfrom()

	/*Creare socket UDP*/
 	socketUDP = socket(PF_INET, SOCK_DGRAM, 0);
 	if (socketUDP == -1) {
 		perror("UDP socket creation failed in client.\n");
        printf("Error in client: %d\n", processID);
 	}

    /* refolosire socket */
    if (setsockopt(socketUDP, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0)
    error("setsockopt(SO_REUSEADDR) failed");

 	/*Creare socket TCP*/
 	socketTCP = socket(AF_INET , SOCK_STREAM , 0);
	if (socketTCP == -1) {
 		perror("TCP socket creation failed in client:\n");
        printf("Error in client: %d\n", processID);
 	}

 	/*Configure settings struct TCP*/
 	memset((char *) &structTCP, 0, sizeof(structTCP));
 	structTCP.sin_family = AF_INET;
    structTCP.sin_addr.s_addr = inet_addr(argv[1]);
    structTCP.sin_port = htons(atoi(argv[2]));

    /*Configure settings struct UDP*/
    memset((char *) &structUDP, 0, sizeof(structUDP));
 	structUDP.sin_family = AF_INET;
    structUDP.sin_port = htons(atoi(argv[2]));
    inet_aton(argv[1], (struct in_addr *) &(structUDP.sin_addr));
    
    int connectEr = connect(socketTCP, (struct sockaddr *) &structTCP, sizeof(structTCP));
    if (connectEr == -1) {
        perror("In client connect error: ");
    }

    char * fileName = (char *)calloc(40, sizeof(char));
    sprintf(fileName, "client-%d.log", getpid());
    FILE * file = fopen(fileName, "w");

    fd_set read_fds;    //multimea de citire folosita in select()
    fd_set tmp_fds;     //multime folosita temporar 

    FD_ZERO(&read_fds);
    FD_ZERO(&tmp_fds);

    FD_SET(socketTCP, &read_fds);
    FD_SET(fileno(stdin), &read_fds);

    int fdmax = socketTCP;
    int j = 0;
    char ** lastLoginStrings = NULL;
    while(1) {
        tmp_fds = read_fds;
        int selectEr = select(fdmax + 1, &tmp_fds, NULL, NULL, NULL);
        if (selectEr == -1) {
            error("ERROR in select");
        }
        for (j = 0; j <= fdmax + 1; j++)
        if (FD_ISSET(j, &tmp_fds)  && j == fileno(stdin))
        {
            memset(buf, 0, BUFLEN);
            fgets(buf, BUFLEN, stdin);

            //tine minte ultima comanda de login (pentru unlock)
            if (memcmp(buf,"login", 5) == 0) {
                /*login numar-card pin */
                lastLoginStrings = split(buf);
            }

            //scrie in fisier log:
            fprintf(file, "%s", buf);

            //comunicare prin udp pentru deblocare
            if (memcmp(buf, "unlock", 6) == 0) {
                memset(buf, 0, BUFLEN);
                //trimite catre server comanda unlock <NumarCard>
                sprintf(buf, "unlock %s", lastLoginStrings[1]);
                int sentLen =  sendto(socketUDP, buf, strlen(buf), 0, (struct sockaddr *)&structUDP, sizeof(structUDP));
                if (sentLen == -1) {
                    perror("Error at sending Unlock request to server.");
                }

                memset(buf, 0, BUFLEN);
                int recvfromLen =  recvfrom(socketUDP, buf, BUFLEN, 0, (struct sockaddr *)&serverStructUDP, (socklen_t *)&(serverStructUDPlen));
                if (recvfromLen == -1) {
                    perror("Error at receiving from server.");
                }
                printf("%s\n\n", buf);
                fprintf(file, "%s\n\n", buf);

                if (memcmp(buf, "UNLOCK> -6 : Operatie esuata", strlen("UNLOCK> -6 : Operatie esuata")) == 0) {
                    continue;
                }

                //cat timp se incearca deblocarea contului prin inserarea parolei:
                while(memcmp(buf, "UNLOCK> Client deblocat", strlen("UNLOCK> Client deblocat") ) != 0) { 
                    //clientul scire parola
                    memset(buf, 0, BUFLEN);
                    fgets(buf, BUFLEN, stdin);
                    fprintf(file, "%s", buf);

                    //trimite parola:
                    sentLen =  sendto(socketUDP, buf, strlen(buf), 0, (struct sockaddr *)&structUDP, sizeof(structUDP));
                    if (sentLen == -1) {
                        perror("Error at sending password to server.");
                    }

                    //Asteapta confirmare:
                    memset(buf, 0, BUFLEN);
                    recvfromLen =  recvfrom(socketUDP, buf, BUFLEN, 0, (struct sockaddr *)&serverStructUDP, (socklen_t *)&(serverStructUDPlen));
                    if (recvfromLen == -1) {
                        perror("Error at receiveing answer from server.");
                    }
                    printf("%s\n\n", buf);
                    fprintf(file, "%s\n\n", buf);
                }
                continue;
            }

            if(memcmp(buf, "quit", 4) != 0 && loginFlag == 0 && memcmp(buf, "login", 5) != 0) {
                
                /*
                    Daca utilizatorul nu este logat si
                    foloseste o comanda diferita de quit si login
                    atunci eroare.
                */
                    printf("-1 : Clientul nu este autentificat\n");
                    fprintf(file, "%s\n", "-1 : Clientul nu este autentificat\n");
                    continue;
            }

            //daca utilizatorul a inchis conexiunea
            if (memcmp(buf, "quit", 4) == 0) {
                quitFlag = 1;
            }

            if (strlen(buf) > 5 && memcmp(buf, "logout", 6) == 0) {
                loginFlag = 0;
            }

            int sentLen = send(socketTCP, buf, strlen(buf),  0);
            if (sentLen == -1) {
                perror("Error at sending message to server.");
            }

            if (quitFlag == 1) {
                fclose(file);
                break;
            }
            
            memset(buf, 0, BUFLEN);
            int recvLen = recv(socketTCP, buf, BUFLEN,  0);
            if (recvLen == -1) {
                perror("Error at receiving message from server.");
            }

            if (recvLen == 0) {
                printf("Server closed\n");
            }

            //verifica daca a avut succes login-ul:
            if (strlen(buf) > 11 && memcmp(buf, "ATM> Welcome", 11) == 0) {
                if (loginFlag == 0) {
                    loginFlag = 1;
                } else {
                    //este logat deja cineva pe acest atm:
                    printf("-2 : Sesiune deja deschisa\n");
                    fprintf(file, "%s\n", "-2 : Sesiune deja deschisa\n");
                    continue;
                }
            }

            //scrie in fisier log raspunsul:
            fprintf(file, "%s\n\n", buf);
            printf("%s\n\n", buf);

            //daca de la server-ul a anuntat ca se inchide:
            if (memcmp(buf, "Server", 6) == 0) {
                fclose(file);
                break;
            }
        } else {
            if (FD_ISSET(j, &tmp_fds) != 0 && j == socketTCP) {
                memset(buf, 0, BUFLEN);
                int recvLen = recv(socketTCP, buf, BUFLEN,  0);
                if (recvLen == -1) {
                    error("Error at receiving message from server in client.");
                }
                if (memcmp(buf, "Server", 6) == 0) {
                    //scrie in fisier log raspunsul:
                    fprintf(file, "%s\n\n", buf);
                    printf("%s\n\n", buf);
                    fclose(file);
                    return 0;
                }
            }
        }
    }

    return 0;
}