#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define MAX_CLIENTS	5
#define BUFLEN 256
#define debug_mode 1
#define dbg if (debug_mode == 1)


int nrUsers = 0; //numar utilizatori

void error(char *msg)
{
    perror(msg);
    exit(1);
}

int max(int x, int y) {
	if (x > y) return x;
	return y;
}

typedef struct s {
    int currentSocket; //socket pe care are loc sesiunea. (0) daca nicio sesiune nu e deschisa
    int blocked;      //blocat - 1, deblocat - 0
    int tries; //numar de incercari de conectare
    char nume[13];
    char prenume[13];
    char numarCard[7];
    char pin[5];
    char parolaSecreta[17]; //pentru deblocare
    float sold;
}Session;

/*
    Incarca in memorie toate conturile clientilor.
*/
Session ** loadUsers(char * fileName, int * nrUsers) {
    FILE * f =  fopen(fileName, "r");
    int nr = 0;
    fscanf(f, "%d", &nr);
    *(nrUsers) = nr;
    Session ** l = (Session **)calloc(nr, sizeof(Session *));
    int i;
    //alocare vector useri:
    for (i = 0; i < nr; i++) {
        l[i] = (Session *)calloc(1, sizeof(Session));
    }

    for (i = 0; i < nr; i++) {
        fscanf(f, "%s", l[i]->nume);       
        fscanf(f, "%s", l[i]->prenume);
        fscanf(f, "%s", l[i]->numarCard);
        fscanf(f, "%s", l[i]->pin);
        fscanf(f, "%s", l[i]->parolaSecreta);
        fscanf(f, "%f", &(l[i]->sold));
    }

    fclose(f);
    return l;
}
/*
    Sparge uns tring in cuvinte separate prin spatiu.
    (MAX 10 cuv)
*/
char ** split(char * s) {
    char ** strings = (char **)calloc(10, sizeof(char *));
    int len = strlen(s);
    int lastIndex = 0;
    int i;
    int k = 0;

    for (i = 0; i <= len; i++) {
        if (s[i] == ' ' || s[i] == '\0' || s[i] == '\n') {

            strings[k] = (char *)calloc(20, sizeof(char));
            memcpy(strings[k], s + lastIndex, i - lastIndex);
            lastIndex = i + 1;
            k++;
        }
    }

    return strings;
}

int main(int args, char ** argv) {

    int variabila = 69;
	struct sockaddr_in serverUDP;
	struct sockaddr_in serverTCP;
	struct sockaddr_in clientStruct;
	char * buf = (char *)calloc(BUFLEN, sizeof(char));

	int enable = 1;
	int socketTCP; //socket-ul serverului TCP
	int socketUDP; //socket-ul serverului UDP

    Session ** users = loadUsers(argv[2], &nrUsers); //lista de sesiuni

	/*Creare socket UDP*/
 	socketUDP = socket(AF_INET, SOCK_DGRAM, 0);
 	if (socketUDP == -1) {
 		perror("UDP socket creation failed in server.");
 	}

 	/* refolosire socket UDP*/
    if (setsockopt(socketUDP, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0)
    error("setsockopt(SO_REUSEADDR) failed");

 	/*Creare socket TCP*/
 	socketTCP = socket(AF_INET , SOCK_STREAM , 0);
	if (socketTCP == -1) {
 		perror("TCP socket creation failed in server.");
 	}

    /* refolosire socket TCP*/
    if (setsockopt(socketTCP, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0)
    error("setsockopt(SO_REUSEADDR) failed");

 	/*Configure settings Server TCP*/
 	memset((char *) &serverTCP, 0, sizeof(serverTCP));
 	serverTCP.sin_family = AF_INET;
    serverTCP.sin_addr.s_addr = inet_addr("127.0.0.1");
    serverTCP.sin_port = htons(atoi(argv[1]));

    /*Configure settings Server UDP*/
    memset((char *) &serverUDP, 0, sizeof(serverUDP));
 	serverUDP.sin_family = AF_INET;
    serverUDP.sin_addr.s_addr = inet_addr("127.0.0.1");
    serverUDP.sin_port = htons(atoi(argv[1]));

    /* bind server's IP to socketUDP */
    int bindEr = bind(socketUDP, (struct sockaddr *)&serverUDP, sizeof(serverUDP));
    if (bindEr == -1) {
    	perror("Bind error UDP.");
    }

    /* bind server's IP to MASTER socketTCP */
    bindEr = bind(socketTCP, (struct sockaddr *)&serverUDP, sizeof(serverUDP));
    if (bindEr == -1) {
    	perror("Bind error TCP.");
    }

    /* asculta conexiuni noi pe socketTCP (aka Master Socket) */
    int listenEr = listen(socketTCP, MAX_CLIENTS);
    if (listenEr == -1) {
    	perror("Listen error.");
    }

    struct in_addr client;
 //   int clientStructLen = sizeof(struct in_addr);
    int clientStructLen = 0;
 //   int clientSocket = 0;

    fd_set read_fds;	//multimea de citire folosita in select()
    fd_set tmp_fds;		//multime folosita temporar 
    int fdmax;		//valoare maxima file descriptor din multimea read_fds

    //golim multimea de descriptori de citire (read_fds) si multimea tmp_fds 
    FD_ZERO(&read_fds);
    FD_ZERO(&tmp_fds);

    //adaug socketul TCP (pe care se asculta conexiuni) in multimea de citire
    FD_SET(socketTCP, &read_fds);

    //adaug socketul UDP (pe care se asculta conexiuni) in multimea de citire
    FD_SET(socketUDP, &read_fds);
    
    fdmax = max(socketUDP, socketTCP);

    //adaug stdin in multimea de citire:
    FD_SET(fileno(stdin), &read_fds);

    fdmax = max(fdmax, fileno(stdin));

    int i = 0;
    int newSocket = 0;
    int k = 0;

    Session * lastBlockedCard = NULL; //ultimul card blocat
    Session * lastCard = NULL;
    while (1) {
    	tmp_fds = read_fds;
    	
        //inlatura sockets care de pe care nu avem de citit date tin tmp_fds.
        int selectEr = select(fdmax + 1, &tmp_fds, NULL, NULL, NULL);
		if (selectEr == -1) {
			error("ERROR in select");
		}

        //itereaza toti sockets din setul: tmp_fds
        for (i = 0; i <= fdmax; i++) {
            
            //verifica apartenenta socket-ului i la setul tmp_fds:
            if (FD_ISSET(i, &tmp_fds)) {
                /*
                    Daca sunt date de citit de pe socketTCP
                    atunci exista o noua conexiune in coada
                    de asteptare.
                */
                if (i == socketTCP) {
                    newSocket = accept(socketTCP, (struct sockaddr *)&client, (socklen_t *)&clientStructLen);
                    if (newSocket == -1) {
                        perror("Error accepting new client.");
                    }
                    //adauga noul client in lista de sesiuni deschise:
                    FD_SET(newSocket, &read_fds);

                    //actualizeaza valoarea maxima din fdset:
                    fdmax = max(fdmax, newSocket);
                    
                    continue;
                }

                /*
                    Daca sunt date de citit de pe socketUDP.
                    Atunci un client incearca sa deblocheze un cont.
                */
                if (i == socketUDP) {

                    struct sockaddr_in structClient;
                    int lenClientStruct = sizeof(structClient);
                    memset(buf, 0, BUFLEN);
                    int sizeMSGudp = recvfrom(socketUDP, buf, BUFLEN, 0, (struct sockaddr *)&structClient, (socklen_t *)&lenClientStruct);
                    if (sizeMSGudp == -1) {
                        perror("Error at receiving message from client at UDP socket.");
                    }
                    if (memcmp(buf, "unlock", 6) == 0) { 
                        //mesaj: "unlock <numarCard>" trimis de la client prin udp
                        char ** strings = split(buf);
                        char * numarCardUnlock = strings[1];
                        memset(buf, 0, BUFLEN);
                        int k = 0;
                        lastCard = NULL;
                        //cauta utilizatorul cu numarul de card primit
                        for (k = 0; k < nrUsers; k++) {
                            if (strcmp(users[k]->numarCard, numarCardUnlock) == 0) {
                                lastCard = users[k];
                                break;
                            }
                        }
                        //verifica daca are sens operatia de UNLOCK
                        if (lastCard == NULL || lastCard->tries < 3) {
                            strcpy(buf, "UNLOCK> -6 : Operatie esuata");
                        } else {
                            strcpy(buf, "UNLOCK> Trimite parola secreta");
                        }
                    } else {    //a fost primita o parola pentru ultimul card blocat
                        if (lastBlockedCard != NULL) {
                            buf[strchr(buf, '\n') - buf] = '\0';
                            if (strcmp(lastBlockedCard->parolaSecreta, buf) != 0) {
                                strcpy(buf, "UNLOCK> -7 : Deblocare esuata");
                            } else {
                                lastBlockedCard->tries = 0;
                                strcpy(buf, "UNLOCK> Client deblocat");
                            }
                        }
                    }

                    int sizeMSG = sendto(socketUDP, buf, strlen(buf), 0, (struct sockaddr *)&structClient, clientStructLen);
                    if (sizeMSG == - 1) {
                        perror("Error in server at sending through UDP");
                    }

                    continue;
                }
                /*
                    Daca sunt date de citit de la stdin:
                */
                if (i == fileno(stdin)) {
                    fgets(buf, BUFLEN, stdin);

                    //comanda de quit:
                    if (memcmp("quit", buf, 4) == 0) {
                        //anunta toti clientii de inchiderea serverului:
                        printf("SERVER is closing.\n");
                        strcpy(buf, "Server closed.");
                        for (i = 0; i <= fdmax; i++) {
                            send(i, buf, strlen(buf), 0);
                        }

                    }
                    //inchide programul
                    return 0;
                }

                //Este o cerere de la un client:
                memset(buf, 0, BUFLEN);
                int sizeMSG = read(i, buf, BUFLEN);
                if (sizeMSG == -1) {
                    perror("Error at receiving message from client.");
                }

                //dclientul a inchis conexiunea:
                if (sizeMSG == 0) {
                    //gaseste clientul care a inchis conexiunea:
                    int j = 0;
                    for (j = 0; j < nrUsers; j++) {
                        if (users[j]->currentSocket == i) {
                            //actualizeaza socket-ul folosit de contul gasit
                            users[j]->currentSocket = 0;

                            //reseteaza numarul de incercari:
                            users[j]->tries = 0;
                        }
                    }

                    //sterge socket-ul curent din Set-ul de sockets
                    FD_CLR(i, &read_fds);
                    continue;
                }

                //Daca a fost primit un mesaj nevid:
                if (sizeMSG > 0) {;

                    //separa mesajul:
                    char ** strings = split(buf);                 

                    //curata bufferul de mesajul primit:
                    memset(buf, 0, BUFLEN);

                    //plaseaza un raspuns corespunzator in functie de cerere in buffer:

                    //testare comanda de LOGIN
                    //ex: login < numar card > < pin >
                    if (strcmp("login", strings[0]) == 0) {
                        Session * s = NULL;

                        //cauta utilizator cu <numar card>                       
                        for (k = 0; k < nrUsers; k++) {
                            if (strcmp(users[k]->numarCard, strings[1]) == 0) {
                                s = users[k];
                                break;
                            }
                        }

                        lastCard = s;

                        //testeaza daca a fost gasit <numar card>
                        if (s == NULL) {
                            strcpy(buf, "ATM> -4 : Numar card inexistent");
                        } else
                        /*
                            Daca exista <numar card> verifica daca se afla deja intr-o sesiune:
                            Insemnand ca exista deja un socket pe care se reazlizeaza o comunicare
                            intre detinator si server.
                        */

                        
                        if (s->currentSocket != 0) {
                            strcpy(buf, "ATM> -2 : Sesiune deja deschisa");
                        } else

                        //testeaza daca pin-ul introdus coincide cu cel stiut de server
                        
                        //verifica daca s-a incercat de 3 ori logare pe acest cont cu un pin gresit
                        if(strcmp(s->pin, strings[2]) != 0 && s->tries + 1 >= 3) {
                            strcpy(buf, "ATM> -5 : Card blocat");
                            s->tries += 1;
                            lastBlockedCard = s;
                        } else

                        if (strcmp(s->pin, strings[2]) != 0) {
                            strcpy(buf, "ATM> -3 : Pin gresit");
                            //incrementeaza numarul de incercari de acces:
                            s->tries += 1;
                        }
                        else 
                        //in caz de pin corect:
                        {
                            //trimite mesaj de bun venit:
                            char *  welcome = "ATM> Welcome ";
                            strcpy(buf, welcome);
                            strcat(buf, s->nume);
                            strcat(buf, " ");
                            strcat(buf, s->prenume);

                            //reseteaza numarul de incercari:
                            s->tries = 0;

                            //actualizeaza socketul folosit de utilizator:
                            s->currentSocket = i;
                        }

                    } else {

                    /*
                        Exista o mapare intre socket si sesiune deschisa de utilizator
                        de 1 la 1. Daca nu este o comanda de login, si este livrata
                        printr-un socket de tip TCP atunci aceasta se adreseaza
                        unei sesiuni deja deschise.
                    */
                        Session * activeSession = NULL;
                        for (k = 0; k < nrUsers; k++) {
                            if (users[k]->currentSocket == i) {
                                activeSession = users[k];
                                break;
                            }
                        }

                        //comanda: listsold
                        if (strcmp("listsold", strings[0]) == 0) {
                            sprintf(buf, "ATM> %f", activeSession->sold);
                        }

                        //comanda logout:
                        if (strcmp("logout", strings[0]) == 0) {
                            strcpy(buf, "ATM> deconectare de la bancomat");
                            //actualizare socket folosit de catre utilizatorul curent:
                            activeSession->currentSocket = 0;
                            activeSession->tries = 0;
                        }

                        //comanda putmoney:
                        if (strcmp("putmoney", strings[0]) == 0) {
                            float sum = 0;
                            sscanf(strings[1], "%f", &sum);
                            activeSession->sold += sum;

                            strcpy(buf, "ATM> Suma depusa cu succes");
                        }

                        //comanda getmoney
                        if (strcmp("getmoney", strings[0]) == 0) {
                            int sumaCeruta = atoi(strings[1]);
                            if (sumaCeruta % 10 != 0) {
                                strcpy(buf, "ATM> -9 : Suma nu este multiplu de 10");
                            } else if (activeSession->sold < sumaCeruta) {
                                strcpy(buf, "ATM> -8 : Fonduri insuficiente");
                            } else {
                                activeSession->sold -= sumaCeruta;
                                sprintf(buf, "ATM> Suma %d retrasa cu succes", sumaCeruta);
                            }
                        }
                    }

                    //raspunde clientului
                    int sizeMSG = send(i, buf, strlen(buf), 0);
                    if (sizeMSG == -1) {
                        perror("Error at answering to client.");
                    }
                }
            }
        }
    }

    close(socketTCP);
    close(socketUDP);
	return 0;
}