#include "lib.h"
#include "myLib.h"
 

void placeInPackage(msg * t, Package * p) {
	//read from payload: soh, len, seq, type:
    memcpy(p, t->payload, sizeof(char) * 4);    //write in payload: soh, len, seq, type
    
    int intLEN = 0;
    memcpy(&intLEN, &(p->len), 1);

    int dataSize = intLEN - 5;
    dgb printf("DIMENSIUNE ----------------> %d\n", dataSize);
    //read from msg to data:
    if (dataSize >= 0)
        memcpy(p->data, t->payload + 4, sizeof(char) * dataSize);

    //read CRC from msg
    int checkPosition = p->len - 3;
    memcpy(&(p->check), t->payload + checkPosition, sizeof(unsigned short));

    //read MARK from msg
    int markPosition = p->len - 3;
    p->mark = t->payload[markPosition + 2];
}

void placeInMSG(msg * t, Package * p) {	
	//write in payload: soh, len, seq, type:
    memcpy(t->payload, p, sizeof(char) * 4);
    int intLEN = 0;
    memcpy(&intLEN, &(p->len), 1);
    int dataSize = intLEN - 5;

    //compute message length
    t->len = intLEN + 2;

    //wrtie DATA:
    if (dataSize >= 0)
    	memcpy(t->payload + 4, p->data, sizeof(char) * dataSize);

    //crc from soh len ... to CRC
    unsigned short crc = crc16_ccitt(t->payload, 4 + dataSize);
    dgb printf("CRC la trimtere calculat: %04X\n", crc);
	fflush(stdout);
    //write CRC:
    int checkPosition = 2 + intLEN - 3;
    memcpy(t->payload + checkPosition, &crc, sizeof(unsigned short));

    //write mark
    int markPosition = 2 + intLEN - 1;
	t->payload[markPosition + 2] = p->mark;
}

int checkCRC(msg * t) {

	//position of check sum control:
	int len = 0;
    memcpy(&len, t->payload + 1, 1);   
    unsigned short receivedCheck;
    int checkPosition = 2 + len - 3;
    memcpy(&receivedCheck, t->payload + checkPosition, 2);
    //calculate check:
    unsigned short calculatedCheck = crc16_ccitt(t->payload, checkPosition);
    dgb printf("Calculated CRC: %04X: vs receivedCheck: %04X\n", calculatedCheck, receivedCheck);
    fflush(stdout);
    if (calculatedCheck != receivedCheck) {
    	return 0;
    }
    return 1;
}