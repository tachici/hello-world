#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#ifndef MYLIB
#define MYLIB  


#define MAXL 250
#define timeout 5000

#define true 1
#define false 0
#define bool int

#define dgb if(0)	//switch debug mode!

#define endNotResponding if ( interruptedConnection) { dgb printf("CONNECTION BROKEN[Last package type: %c]\n", package.type); return -1; }


typedef struct p {
    char soh;   // Start-of-Header
    char len;   // Number of bytes from here.
    char seq;   // Sequence number % 64
    char type;  // Type
    char * data;// File bytes | Init info
    unsigned short check;// Control sum.
    char mark;  // End of Block Marker. Defined in S Package.
}Package;

// – ’S’: Send-init  
// – ’F’: File Header
// – ’D’: Data
// – ’Z’: EOF (End Of File)
// – ’B’: EOT(End Of Transaction)  
// – ’Y’: ACK
// – ’N’: NAK
// – ’E’: error

typedef struct d {
    char maxl;  //data max length
    char t;     //time
    char npad;  //Number of padding bytes. 0x00
    char padc;  //Padding char: 0x00
    char eol;   //char used by MARK: 0x0d
    char qctl;  //Not used in Mini-Kermit: VVV
    char qbin;
    char chkt;
    char rept;
    char capa; 
    char r;
}InitInfo;

#endif