#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "lib.h"
#include "myLib.h"
#include "myLibFunctions.h"
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>

#define HOST "127.0.0.1"
#define PORT 10000

static char seq = 0;

//fill InitInfo fields:
void initialise(InitInfo * info) {
    info->maxl = MAXL;   //bytes
    info->t = (char)timeout;
    info->npad = 0x00;
    info->padc = 0x00;
    info->eol = 0x0d;
    info->qctl = 0x00;
    info->qbin = 0x00;
    info->chkt = 0x00;
    info->rept = 0x00;
    info->capa = 0x00;
    info->r = 0x00;
}


void prepareInitMessage(msg * t, Package * p, InitInfo * info) {    
    // payload in memory: soh len seq type [...data...] check mark
    p->soh = 0x01;
    p->len = 2 + sizeof(InitInfo) + 3;       //2 + sizeof(data) + 3
    p->seq = 0x00;
    p->type = 'S';
    memcpy(p->data, info, sizeof(InitInfo));
    //Place everything in payload of msg t.
    placeInMSG(t,  p);
}

void prepareEOT(Package * p) {

    p->seq = seq;

    //compute len: soh len seq type data(EMPTY) CRC MARK
    p->len = 5;

    //write type
    p->type = 'B';
}

void prepareHeader(Package * p, char * fileName) {
    p->seq = seq;
    //compute len: soh len seq type data(EMPTY) CRC MARK
    p->len = 5 + strlen(fileName);
     
    //copy file name in data:
    memcpy(p->data, fileName, sizeof(char) * strlen(fileName));

    //write type
    p->type = 'F';
}

void prepareDATA(Package * p, int dataSize) {
    p->seq = seq;

    //compute len: soh len seq type data(EMPTY) CRC MARK
    p->len = 5 + dataSize;

    //write type
    p->type = 'D';
}

/*
    Sends message t to receiver.
    If timeout miliseconds pass then
    try 3 more times.
    If no ACK is received => return 0;
    If sender receives NACK resend last message.
*/
int enhancedSendMessage(msg * t, msg * ACK, Package * p) {
    send_message(t);
    
    
    dgb printf("Trimite mesaj cu: seq [%d] tip [%c] dataSize [%d]\n", p->seq, p->type, p->len - 5);
    
    ACK = receive_message_timeout(timeout);
    int retries = 0;
    if (ACK == NULL) {
        dgb printf("------------No message recieved after TIME from reciever.------------\n");
        while (ACK == NULL && retries < 3) {
            send_message(t);
            
            ACK = receive_message_timeout(timeout);
            retries++;
        }
    }
    if (retries == 3) {
        //Connection lost
        dgb printf("No message recieved after 3 tries from reciever.\n");
        return 0;
    }

    placeInPackage(ACK, p);

    if (p->seq != (seq + 1) % 64) {
        dgb printf("NEEED RESEND! ffs: received in s: %d expected: %d\n", p->seq , (seq + 1) % 64);
       return enhancedSendMessage( t, ACK, p);
    }
    
    if (p->type == 'N') {   //package got to receiver corrupted
        while (p->type == 'N') {
            dgb printf("Package arrived to receiver corrupted!\n");
            
            placeInPackage(t, p);
            p->seq = seq;
            placeInMSG(t, p);
            
            send_message(t);
            
            dgb printf("Waiting for ACK: %d\n", p->seq);

            ACK = receive_message_timeout(timeout);

            retries = 0;
            if (ACK == NULL) {
                dgb printf(".------------No message recieved after TIME from reciever.------------\n");
                while (ACK == NULL && retries < 3) {
                    send_message(t);
                    ACK = receive_message_timeout(timeout);
                    retries++;
                }
            }
            if (retries == 3) {
                //Connection lost
                dgb printf("------------No message recieved after 3 tries from reciever.------------\n");
                return 0;
            }

            placeInPackage(ACK, p);
            if (p->seq != (seq + 1) % 64) {
                dgb printf("NEEED RESEND!  received in s: %d expected: %d\n", p->seq , (t->payload[2] + 1) % 64);
                return enhancedSendMessage( t, ACK, p);
            }

            seq = (seq + 2) % 64;
        }
    } else {
        placeInPackage(ACK, p);
        seq = (seq + 2) % 64;
    }

    placeInPackage(ACK, p);
    dgb printf("Got ACK with %d for sent package: %d\n", p->seq, t->payload[2]);
    return 1;
}

void prepareEOF(Package * p) {
    //increment seq
    p->seq = seq;

    //compute len: soh len seq type data(EMPTY) CRC MARK
    p->len = 5;

    //write type
    p->type = 'z';
}
/*
    Send one file to receiver.
*/
void sendFile(msg * t, msg * ACK, Package * p, int fileDescriptor) {
    int readBytes = 1;

    /*
        Send file one msg at a time.
    */
    dgb printf("SEND FILE: %d\n", fileDescriptor);
    do {
        readBytes = read(fileDescriptor, p->data, (MAXL )* sizeof(char));
        dgb printf("read() status: %s\n", strerror(errno));
        dgb printf("READ bytes = (%d)\n", readBytes);
        dgb printf("Read line: %s\n", p->data);
        prepareDATA(p, readBytes);
        placeInMSG(t, p);
        enhancedSendMessage(t, ACK, p);

    } while (readBytes > 0);
    //Inform receiver to close the file. File transfer done.
    prepareEOF(p);
    placeInMSG(t, p);
    enhancedSendMessage(t, ACK, p);
    close(fileDescriptor);
}
//Sender sends the file name.
int sendFileHeader(msg * t, msg * ACK, Package * p, char * fileName) {
    int fileDescriptor = open(fileName, O_RDONLY);
    prepareHeader(p,  fileName);
    dgb printf("SENDING: %s ---FILE\n", p->data);
    placeInMSG(t, p);
    enhancedSendMessage(t, ACK, p);
    return fileDescriptor;
}

int main(int argc, char** argv) {
 
    dgb printf("RULEAZA KSENDER\n");
    fflush(stdout);
    msg t;
    msg * ACK = NULL;
    Package package;
    package.data = (char *)calloc(MAXL + 1, sizeof(char));

    InitInfo initialiseInfo;
    int i = 0;
    init(HOST, PORT);

    //intialise initialiseInfo:
    initialise(&initialiseInfo);
    //prepare "S" package:
    prepareInitMessage(&t, &package, &initialiseInfo);
    //send init package:
    dgb printf("Send init message!\n");
    enhancedSendMessage(&t, ACK, &package);

    dgb printf("Files to be transmited: %d.\n", argc - 1);
    int fileDescriptor = 0;
    for (i = 1; i <= argc - 1; i++) {   //for all files to be transmited
         
        fileDescriptor = sendFileHeader(&t, ACK, &package, argv[i]);
        sendFile(&t, ACK, &package, fileDescriptor);

    }
    
    
    prepareEOT(&package);
    placeInMSG(&t, &package);
    enhancedSendMessage(&t, ACK, &package);

    dgb printf("SENDER CLOSED!\n");

    return 0;
}
