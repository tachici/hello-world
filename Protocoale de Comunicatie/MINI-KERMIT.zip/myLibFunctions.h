#ifndef MYLIBFUNCTIONS
#define MYLIBFUNCTIONS

void placeInPackage(msg * t, Package * p);
void placeInMSG(msg * t, Package * p);
int checkCRC(msg * t);

#endif