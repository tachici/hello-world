#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "lib.h"
#include "myLib.h"
#include "myLibFunctions.h"

#define HOST "127.0.0.1"
#define PORT 10001


static char currentSeq = -1;
static char lastACKSeq = 0;

/*
    Save sender's information in info structure.
*/
void receiveInitMessage(msg * t, Package * p, InitInfo * info) {
     
    placeInPackage( t, p);

    //Copiaza informationa;
    memcpy(info, p->data, sizeof(InitInfo));
}

void prepareACK(Package * p) {
    //increment seq
    p->seq = currentSeq;
 
    //load len: soh len seq type data(EMPTY) CRC MARK
    p->len = 6;

    //write type
    p->type = 'Y';

}

 void prepareNACK(Package * p) {
    //increment seq
    p->seq = currentSeq;

    //load len: soh len seq type data(EMPTY) CRC MARK
    p->len = 6;

    //write type
    p->type = 'N';
}

void sendACK(msg * t, Package * p) {
    lastACKSeq = currentSeq;
    prepareACK(p);
    placeInMSG(t, p);
    send_message(t);
}

void sendNACK(msg * t, Package * p) {
    
    prepareNACK(p);
    placeInMSG(t, p);
    send_message(t);
}

//if first = 1 wait for first initial packet
int enhancedReceive(msg * r, msg * t, Package * p, int first) {
    int nrRetries = 0;
    if (first == 1)
        r = receive_message_timeout(timeout * 3);
    else
        r = receive_message_timeout(timeout);
    if ( r == NULL) {
        dgb printf("------------PACKAGE NOT RECEIVED in TIME!------------\n");
        //No package was received from sender in TIME
        //Send LAST PACKAGE (ACK or NACK) three times before disconencting:
        while (nrRetries < 3) {
            send_message(t);
            r = receive_message_timeout(timeout);
            if (r != NULL) break;
            nrRetries++;
        }

        if (nrRetries == 3) return 1; //close connection
    }
    dgb printf("PACKAGE RECEIVED !\n");
    /*
        Check if the message got corrupted. And
        request a retransmission by sending a NACK.
    */

    if (r->payload[2] != (currentSeq + 1) % 64) {
        dgb printf("[RECEIVER]: received seq: %d, EXPECTED: %d\n", r->payload[2], (currentSeq + 1) % 64);
        return enhancedReceive(r, t, p, 0);
    }

    if (checkCRC(r) == 0) {
        while (checkCRC(r) == 0) {
            dgb printf("CORRUPTED PACKAGE!\n");
            
            sendNACK(t, p);
            
            dgb printf("Waiting for uncorrupted package in receiver: %d \n", p->seq);
            r = receive_message_timeout(timeout);
            

            if (r == NULL) {    //check again if timeout occurs and try three more times
                dgb printf("------------PACKAGE NOT RECEIVED in TIME!------------\n");
                nrRetries = 0;
                while (nrRetries < 3) {
                    send_message(t);
                    r = receive_message_timeout(timeout);
                    if (r != NULL) break;
                    nrRetries++;
                }
                if (nrRetries == 3) return 1; //close connection
            }

            if (r->payload[2] != (currentSeq + 1) % 64) {
                dgb printf("[RECEIVER]: received seq: %d, EXPECTED: %d\n", r->payload[2], (currentSeq + 1) % 64);
                return enhancedReceive(r, t, p, 0);
            }


            placeInPackage(r, p);   //place in package back all information received
            currentSeq = (currentSeq + 2) % 64; //remember sequence number to be transmited with ACK
        }
    } else {
        placeInPackage(r, p);
        currentSeq = (currentSeq + 2) % 64;
        return 0;
    }
 

    placeInPackage(r, p);   //place in package back all information received
    
  //  p->seq = (p->seq + 1) % 64;
    return 0;
}
/*
    Creates a file with the file header stored in data.
*/
int createFile(Package * p) {
    char * name = (char *)calloc(MAXL, sizeof(char));
    char * recvAppend = (char *)calloc(MAXL, sizeof(char));
    strcpy(recvAppend, "recv_");
    int dataSize = p->len - 5;
    int fileDescriptor = 0;
    if (dataSize < 0) {
        dgb printf("RECEIVED WRONG DATA SIZE\n");
    }
    memcpy(name, p->data, dataSize);
    strcat(recvAppend, name);
    dgb printf("CREATING FILE: %s\n", recvAppend);

    fileDescriptor = open(recvAppend, O_CREAT | O_WRONLY | O_APPEND | O_TRUNC , S_IWUSR | S_IRUSR);

    free(name);
    free(recvAppend);

    return fileDescriptor;
}
/*
    Write packet of data to file.
*/
void writeData(Package * p, int fileDescriptor) {
    int intLEN = 0;
    memcpy(&intLEN, &(p->len), 1 * sizeof(char));
    int sizeOfData = intLEN - 5;
    if (sizeOfData <= 0) {
    dgb printf("Wrong data size: %d in DATA pachet.\n", sizeOfData);
    }
    dgb printf("Scrie in fisier: --------- %s ----\n", p->data);
    write(fileDescriptor, p->data, sizeOfData);
}

int main(int argc, char** argv) {
    
    dgb printf("RULEAZA KRECEIVER\n");
    fflush(stdout);
    msg * r = NULL;
    msg t;
    int interruptedConnection = 0;
    Package package;
    //initializare camp data pachet
    package.data = (char *)calloc(MAXL, sizeof(char));

 
     
    init(HOST, PORT);
 
     dgb printf("DEBUG MOD ON!\n" );


    interruptedConnection = enhancedReceive(r, &t, &package, 1);
    endNotResponding;

    
 
    dgb printf("Receiver ACCEPTS transaction!\n");
   
    dgb printf("RECEIVED type : [%c] message.\n", package.type);
    sendACK(&t, &package);          //places in package an ACK 
     

    int fileDescriptor;
    while (1) {
        interruptedConnection = enhancedReceive(r, &t, &package, 0);
        endNotResponding;
        dgb printf("Received type [%c] ACK : [%d] message.\n", package.type, package.seq);
 
            if (package.type == 'F') {
            dgb printf("Received file header.\n");
                fileDescriptor = createFile(&package);
            }
            
            if (package.type == 'D') {
            dgb printf("Received DATA.\n"); 
                    writeData(&package, fileDescriptor);
            }

            if (package.type == 'Z') {
            dgb printf("Received CLOSE FILE package!\n");
                close(fileDescriptor);
            }

            if (package.type == 'B') {
            dgb printf("TRANSACTION TERMINATED by sender!\n");
                break;
            }
 
        sendACK(&t, &package);          //places in package an ACK 
        

        dgb printf("Sent ACK [%c] seq : [%d] message.\n", package.type, package.seq);
    }

     
    dgb printf("RECEIVED type : [%c] message.\n", package.type);
    sendACK(&t, &package);          //places in package an ACK     

	dgb printf("RECEIVER CLOSED!\n");
	return 0;
}







//JACK SPARROW